#!/bin/bash

echo "La fecha y hora actual son: $(date +"%Y-%m-%d %H:%M:%S")"
